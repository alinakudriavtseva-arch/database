import time
import os

class Student:
    def __init__(self, last_name, first_name, grade, classroom, bus):
        self.last_name = last_name
        self.first_name = first_name
        self.grade = grade
        self.classroom = classroom
        self.bus = bus
    
    def __str__(self):
        return f"{self.last_name}, {self.first_name}, {self.grade}, {self.classroom}, {self.bus}"

class Teacher:
    def __init__(self, last_name, first_name, classroom):
        self.last_name = last_name
        self.first_name = first_name
        self.classroom = classroom
    
    def __str__(self):
        return f"{self.last_name}, {self.first_name}, {self.classroom}"

class SchoolSearch:
    def __init__(self):
        self.students = []
        self.teachers = []
        self.classroom_to_teachers = {}
        self.load_data()
    
    def load_data(self):
        # Завантаження студентів з list.txt
        try:
            with open('list.txt', 'r', encoding='utf-8') as file:
                for line in file:
                    parts = line.strip().split(',')
                    if len(parts) == 5:
                        student = Student(
                            parts[0].strip(),
                            parts[1].strip(),
                            parts[2].strip(),
                            parts[3].strip(),
                            parts[4].strip()
                        )
                        self.students.append(student)
            print(f"Завантажено {len(self.students)} студентів")
        except FileNotFoundError:
            print("Файл list.txt не знайдено")
        except Exception as e:
            print(f"Помилка завантаження list.txt: {e}")
        
        # Завантаження вчителів з teachers.txt
        try:
            with open('teachers.txt', 'r', encoding='utf-8') as file:
                for line in file:
                    parts = line.strip().split(',')
                    if len(parts) == 3:
                        teacher = Teacher(
                            parts[0].strip(),
                            parts[1].strip(),
                            parts[2].strip()
                        )
                        self.teachers.append(teacher)
                        
                        # Додаємо вчителя до словника класних кімнат
                        if teacher.classroom not in self.classroom_to_teachers:
                            self.classroom_to_teachers[teacher.classroom] = []
                        self.classroom_to_teachers[teacher.classroom].append(teacher)
            print(f"Завантажено {len(self.teachers)} вчителів")
        except FileNotFoundError:
            print("Файл teachers.txt не знайдено")
        except Exception as e:
            print(f"Помилка завантаження teachers.txt: {e}")
    
    def get_teachers_for_classroom(self, classroom):
        """Отримати вчителів для класної кімнати"""
        if classroom in self.classroom_to_teachers:
            return self.classroom_to_teachers[classroom]
        return []
    
    def search_student_by_last_name(self, last_name):
        """Пошук студента за прізвищем"""
        result = []
        for student in self.students:
            if student.last_name.upper() == last_name.upper():
                teachers = self.get_teachers_for_classroom(student.classroom)
                teacher_info = "UNKNOWN, UNKNOWN"
                if teachers:
                    teacher = teachers[0]  # Беремо першого вчителя
                    teacher_info = f"{teacher.last_name}, {teacher.first_name}"
                
                result.append(f"{student.last_name}, {student.first_name}, {student.grade}, {student.classroom}, {student.bus}, {teacher_info}")
        
        return result
    
    def search_students_by_teacher(self, teacher_last_name):
        """Пошук студентів за вчителем"""
        result = []
        
        # Знаходимо класні кімнати, де викладає цей вчитель
        teacher_classrooms = set()
        for teacher in self.teachers:
            if teacher.last_name.upper() == teacher_last_name.upper():
                teacher_classrooms.add(teacher.classroom)
        
        # Знаходимо студентів у цих класних кімнатах
        for student in self.students:
            if student.classroom in teacher_classrooms:
                result.append(f"{student.last_name}, {student.first_name}")
        
        return result
    
    def search_students_by_grade(self, grade):
        """Пошук студентів за класом"""
        result = []
        for student in self.students:
            if student.grade == grade:
                teachers = self.get_teachers_for_classroom(student.classroom)
                teacher_info = "UNKNOWN, UNKNOWN"
                if teachers:
                    teacher = teachers[0]
                    teacher_info = f"{teacher.last_name}, {teacher.first_name}"
                result.append(f"{student.last_name}, {student.first_name}, {teacher_info}")
        
        return result
    
    def search_students_by_classroom(self, classroom):
        """Пошук студентів за класною кімнатою"""
        result = []
        for student in self.students:
            if student.classroom == classroom:
                result.append(f"{student.last_name}, {student.first_name}")
        
        return result
    
    def search_students_by_bus(self, bus):
        """Пошук студентів за автобусом"""
        result = []
        for student in self.students:
            if student.bus == bus:
                result.append(f"{student.last_name}, {student.first_name}")
        
        return result
    
    def search_teacher_by_classroom(self, classroom):
        """Пошук вчителя за класною кімнатою"""
        result = []
        for teacher in self.teachers:
            if teacher.classroom == classroom:
                result.append(f"{teacher.last_name}, {teacher.first_name}")
        
        return result
    
    def search_teachers_by_grade(self, grade):
        """Пошук вчителів за класом"""
        result = []
        teacher_set = set()
        
        # Знаходимо класні кімнати, де є студенти цього класу
        grade_classrooms = set()
        for student in self.students:
            if student.grade == grade:
                grade_classrooms.add(student.classroom)
        
        # Знаходимо вчителів для цих класних кімнат
        for classroom in grade_classrooms:
            teachers = self.get_teachers_for_classroom(classroom)
            for teacher in teachers:
                teacher_key = f"{teacher.last_name}, {teacher.first_name}"
                if teacher_key not in teacher_set:
                    teacher_set.add(teacher_key)
                    result.append(teacher_key)
        
        return result
    
    def show_all_students(self):
        """Показати всіх студентів"""
        result = []
        for student in self.students:
            teachers = self.get_teachers_for_classroom(student.classroom)
            teacher_info = "UNKNOWN, UNKNOWN"
            if teachers:
                teacher = teachers[0]
                teacher_info = f"{teacher.last_name}, {teacher.first_name}"
            result.append(f"{student.last_name}, {student.first_name}, {student.grade}, {student.classroom}, {student.bus}, {teacher_info}")
        
        return result
    
    def show_menu(self):
        """Показати меню"""
        print("\n" + "="*50)
        print("         ШКІЛЬНА СИСТЕМА ПОШУКУ")
        print("="*50)
        print("1. Пошук студента за прізвищем")
        print("2. Пошук студентів за вчителем") 
        print("3. Пошук студентів за класом")
        print("4. Пошук студентів за класною кімнатою")
        print("5. Пошук студентів за автобусом")
        print("6. Пошук вчителя за класною кімнатою")
        print("7. Пошук вчителів за класом")
        print("8. Показати всіх студентів")
        print("9. Вихід")
        print("="*50)
    
    def run(self):
        """Головний цикл програми"""
        print("Шкільна система пошуку - готова до роботи!")
        
        while True:
            self.show_menu()
            choice = input("Оберіть опцію (1-9): ").strip()
            
            start_time = time.time()
            
            if choice == "1":
                last_name = input("Введіть прізвище студента: ").strip()
                results = self.search_student_by_last_name(last_name)
            
            elif choice == "2":
                teacher_name = input("Введіть прізвище вчителя: ").strip()
                results = self.search_students_by_teacher(teacher_name)
            
            elif choice == "3":
                grade = input("Введіть клас: ").strip()
                results = self.search_students_by_grade(grade)
            
            elif choice == "4":
                classroom = input("Введіть номер класної кімнати: ").strip()
                results = self.search_students_by_classroom(classroom)
            
            elif choice == "5":
                bus = input("Введіть номер автобуса: ").strip()
                results = self.search_students_by_bus(bus)
            
            elif choice == "6":
                classroom = input("Введіть номер класної кімнати: ").strip()
                results = self.search_teacher_by_classroom(classroom)
            
            elif choice == "7":
                grade = input("Введіть клас: ").strip()
                results = self.search_teachers_by_grade(grade)
            
            elif choice == "8":
                results = self.show_all_students()
            
            elif choice == "9":
                print("До побачення!")
                break
            
            else:
                print("Невірний вибір! Спробуйте ще раз.")
                continue
            
            end_time = time.time()
            duration_ms = int((end_time - start_time) * 1000)
            
            # Вивід результатів
            if choice != "9":
                if results:
                    for result in results:
                        print(result)
                else:
                    print("Нічого не знайдено")
                
                print(f"{duration_ms}ms")

def main():
    # Перевіряємо наявність файлів
    if not os.path.exists('list.txt'):
        print("Помилка: Файл list.txt не знайдено!")
        return
    
    if not os.path.exists('teachers.txt'):
        print("Помилка: Файл teachers.txt не знайдено!")
        return
    
    # Запускаємо програму
    school_system = SchoolSearch()
    school_system.run()

if __name__ == "__main__":
    main()